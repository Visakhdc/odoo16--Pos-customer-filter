from . import res_partner
from . import hr_employee
from . import pos_session